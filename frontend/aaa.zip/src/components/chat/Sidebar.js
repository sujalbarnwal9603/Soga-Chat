"use client"
import { useAuth } from "../../contexts/AuthContext"
import { useChat } from "../../contexts/ChatContext"
import ChatList from "./ChatList"
import "./Sidebar.css"

const Sidebar = ({ onShowUserSearch, onShowGroupModal, onShowProfile }) => {
  const { user, logout } = useAuth()
  const { chats } = useChat()

  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <div className="user-info" onClick={onShowProfile}>
          <img
            src={user?.avatar || "/placeholder.svg?height=40&width=40"}
            alt={user?.fullName}
            className="user-avatar"
          />
          <div className="user-details">
            <h3>{user?.fullName}</h3>
            <span className="user-status">Online</span>
          </div>
        </div>

        <div className="header-actions">
          <button className="action-btn" onClick={onShowUserSearch} title="New Chat">
            💬
          </button>
          <button className="action-btn" onClick={onShowGroupModal} title="New Group">
            👥
          </button>
          <button className="action-btn logout-btn" onClick={logout} title="Logout">
            🚪
          </button>
        </div>
      </div>

      <div className="sidebar-content">
        <div className="chats-header">
          <h4>Chats ({chats.length})</h4>
        </div>
        <ChatList />
      </div>
    </div>
  )
}

export default Sidebar
