import { useChat } from "../../contexts/ChatContext"
import MessageList from "./MessageList"
import MessageInput from "./MessageInput"
import ChatHeader from "./ChatHeader"
import "./ChatArea.css"

const ChatArea = () => {
  const { selectedChat } = useChat()

  if (!selectedChat) {
    return (
      <div className="chat-area no-chat">
        <div className="no-chat-content">
          <div className="no-chat-icon">💬</div>
          <h2>Welcome to Soga Chat</h2>
          <p>Select a chat to start messaging</p>
        </div>
      </div>
    )
  }

  return (
    <div className="chat-area">
      <ChatHeader />
      <MessageList />
      <MessageInput />
    </div>
  )
}

export default ChatArea
