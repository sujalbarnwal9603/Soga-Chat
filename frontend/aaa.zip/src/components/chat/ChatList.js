"use client"
import { useChat } from "../../contexts/ChatContext"
import { useAuth } from "../../contexts/AuthContext"
import "./ChatList.css"

const ChatList = () => {
  const { chats, selectedChat, selectChat, loading } = useChat()
  const { user } = useAuth()

  const getSender = (chat) => {
    if (chat.isGroupChat) {
      return chat.chatName
    }
    return chat.users.find((u) => u._id !== user._id)?.fullName || "Unknown User"
  }

  const getSenderAvatar = (chat) => {
    if (chat.isGroupChat) {
      return "/placeholder.svg?height=50&width=50"
    }
    const sender = chat.users.find((u) => u._id !== user._id)
    return sender?.avatar || "/placeholder.svg?height=50&width=50"
  }

  const formatTime = (timestamp) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffInHours = (now - date) / (1000 * 60 * 60)

    if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } else {
      return date.toLocaleDateString()
    }
  }

  const getLatestMessage = (chat) => {
    if (!chat.latestMessage) return "No messages yet"

    const isOwn = chat.latestMessage.sender._id === user._id
    const prefix = isOwn ? "You: " : ""
    const content =
      chat.latestMessage.content.length > 30
        ? chat.latestMessage.content.substring(0, 30) + "..."
        : chat.latestMessage.content

    return prefix + content
  }

  if (loading) {
    return (
      <div className="chat-list-loading">
        <div className="spinner"></div>
        <p>Loading chats...</p>
      </div>
    )
  }

  if (chats.length === 0) {
    return (
      <div className="no-chats">
        <p>No chats yet. Start a new conversation!</p>
      </div>
    )
  }

  return (
    <div className="chat-list">
      {chats.map((chat) => (
        <div
          key={chat._id}
          className={`chat-item ${selectedChat?._id === chat._id ? "active" : ""}`}
          onClick={() => selectChat(chat)}
        >
          <div className="chat-avatar">
            <img src={getSenderAvatar(chat) || "/placeholder.svg"} alt={getSender(chat)} />
            {chat.isGroupChat && <span className="group-indicator">{chat.users.length}</span>}
          </div>

          <div className="chat-info">
            <div className="chat-header">
              <h4 className="chat-name">{getSender(chat)}</h4>
              {chat.latestMessage && <span className="chat-time">{formatTime(chat.latestMessage.createdAt)}</span>}
            </div>
            <p className="latest-message">{getLatestMessage(chat)}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

export default ChatList
