"use client"

import { useEffect, useRef } from "react"
import { useChat } from "../../contexts/ChatContext"
import { useAuth } from "../../contexts/AuthContext"
import Message from "./Message"
import "./MessageList.css"

const MessageList = () => {
  const { messages, isTyping } = useChat()
  const { user } = useAuth()
  const messagesEndRef = useRef(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  return (
    <div className="message-list">
      <div className="messages-container">
        {messages.map((message, index) => (
          <Message
            key={message._id}
            message={message}
            isOwn={message.sender._id === user._id}
            showAvatar={index === messages.length - 1 || messages[index + 1]?.sender._id !== message.sender._id}
          />
        ))}

        {isTyping && (
          <div className="typing-indicator">
            <div className="typing-dots">
              <span></span>
              <span></span>
              <span></span>
            </div>
            <span>Someone is typing...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>
    </div>
  )
}

export default MessageList
