import "./Message.css"

const Message = ({ message, isOwn, showAvatar }) => {
  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className={`message ${isOwn ? "own-message" : "other-message"}`}>
      <div className="message-content">
        {!isOwn && showAvatar && (
          <img
            src={message.sender.avatar || "/placeholder.svg?height=32&width=32"}
            alt={message.sender.fullName}
            className="message-avatar"
          />
        )}

        <div className="message-bubble">
          {!isOwn && <div className="message-sender">{message.sender.fullName}</div>}
          <div className="message-text">{message.content}</div>
          <div className="message-time">{formatTime(message.createdAt)}</div>
        </div>
      </div>
    </div>
  )
}

export default Message
