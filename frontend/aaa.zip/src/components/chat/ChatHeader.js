"use client"
import { useChat } from "../../contexts/ChatContext"
import { useAuth } from "../../contexts/AuthContext"
import "./ChatHeader.css"

const ChatHeader = () => {
  const { selectedChat } = useChat()
  const { user } = useAuth()

  if (!selectedChat) return null

  const getChatName = () => {
    if (selectedChat.isGroupChat) {
      return selectedChat.chatName
    }
    return selectedChat.users.find((u) => u._id !== user._id)?.fullName || "Unknown User"
  }

  const getChatAvatar = () => {
    if (selectedChat.isGroupChat) {
      return "/placeholder.svg?height=40&width=40"
    }
    const otherUser = selectedChat.users.find((u) => u._id !== user._id)
    return otherUser?.avatar || "/placeholder.svg?height=40&width=40"
  }

  const getChatInfo = () => {
    if (selectedChat.isGroupChat) {
      return `${selectedChat.users.length} members`
    }
    return "Online" // You can implement online status later
  }

  return (
    <div className="chat-header">
      <div className="chat-header-info">
        <img src={getChatAvatar() || "/placeholder.svg"} alt={getChatName()} className="chat-header-avatar" />
        <div className="chat-header-details">
          <h3>{getChatName()}</h3>
          <span className="chat-header-status">{getChatInfo()}</span>
        </div>
      </div>

      <div className="chat-header-actions">
        <button className="header-action-btn" title="Call">
          📞
        </button>
        <button className="header-action-btn" title="Video Call">
          📹
        </button>
        <button className="header-action-btn" title="More">
          ⋮
        </button>
      </div>
    </div>
  )
}

export default ChatHeader
