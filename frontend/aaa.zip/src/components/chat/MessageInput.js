"use client"

import { useState } from "react"
import { useChat } from "../../contexts/ChatContext"
import { useSocket } from "../../contexts/SocketContext"
import "./MessageInput.css"

const MessageInput = () => {
  const [message, setMessage] = useState("")
  const { sendMessage, selectedChat } = useChat()
  const { socket } = useSocket()

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (message.trim()) {
      await sendMessage(message)
      setMessage("")

      if (socket) {
        socket.emit("stop typing", selectedChat._id)
      }
    }
  }

  const handleTyping = (e) => {
    setMessage(e.target.value)

    if (socket && selectedChat) {
      socket.emit("typing", selectedChat._id)

      // Stop typing after 3 seconds of inactivity
      setTimeout(() => {
        socket.emit("stop typing", selectedChat._id)
      }, 3000)
    }
  }

  return (
    <div className="message-input">
      <form onSubmit={handleSubmit} className="message-form">
        <div className="input-container">
          <button type="button" className="attachment-btn" title="Attach file">
            📎
          </button>

          <input
            type="text"
            value={message}
            onChange={handleTyping}
            placeholder="Type a message..."
            className="message-text-input"
          />

          <button type="button" className="emoji-btn" title="Add emoji">
            😊
          </button>
        </div>

        <button type="submit" className="send-btn" disabled={!message.trim()}>
          ➤
        </button>
      </form>
    </div>
  )
}

export default MessageInput
