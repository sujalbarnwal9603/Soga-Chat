"use client"

import { useState } from "react"
import { useChat } from "../../contexts/ChatContext"
import { userAPI } from "../../services/api"
import Modal from "./Modal"
import "./UserSearchModal.css"

const UserSearchModal = ({ onClose }) => {
  const [searchTerm, setSearchTerm] = useState("")
  const [searchResults, setSearchResults] = useState([])
  const [loading, setLoading] = useState(false)
  const { createChat } = useChat()

  const handleSearch = async (term) => {
    setSearchTerm(term)

    if (term.trim()) {
      setLoading(true)
      try {
        const response = await userAPI.searchUsers(term)
        setSearchResults(response.data || [])
      } catch (error) {
        console.error("Search failed:", error)
        setSearchResults([])
      } finally {
        setLoading(false)
      }
    } else {
      setSearchResults([])
    }
  }

  const handleUserSelect = async (userId) => {
    try {
      await createChat(userId)
      onClose()
    } catch (error) {
      console.error("Failed to create chat:", error)
    }
  }

  return (
    <Modal title="Search Users" onClose={onClose}>
      <div className="user-search-modal">
        <div className="search-input-container">
          <input
            type="text"
            placeholder="Search by name or email..."
            value={searchTerm}
            onChange={(e) => handleSearch(e.target.value)}
            className="search-input"
            autoFocus
          />
        </div>

        <div className="search-results">
          {loading ? (
            <div className="search-loading">
              <div className="spinner"></div>
              <p>Searching...</p>
            </div>
          ) : searchResults.length > 0 ? (
            searchResults.map((user) => (
              <div key={user._id} className="user-result" onClick={() => handleUserSelect(user._id)}>
                <img
                  src={user.avatar || "/placeholder.svg?height=40&width=40"}
                  alt={user.fullName}
                  className="user-result-avatar"
                />
                <div className="user-result-info">
                  <h4>{user.fullName}</h4>
                  <p>{user.email}</p>
                </div>
              </div>
            ))
          ) : searchTerm && !loading ? (
            <div className="no-results">
              <p>No users found</p>
            </div>
          ) : (
            <div className="search-placeholder">
              <p>Start typing to search for users</p>
            </div>
          )}
        </div>
      </div>
    </Modal>
  )
}

export default UserSearchModal
