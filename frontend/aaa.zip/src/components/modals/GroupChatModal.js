"use client"

import { useState } from "react"
import { useChat } from "../../contexts/ChatContext"
import { userAPI } from "../../services/api"
import Modal from "./Modal"
import "./GroupChatModal.css"

const GroupChatModal = ({ onClose }) => {
  const [groupName, setGroupName] = useState("")
  const [searchTerm, setSearchTerm] = useState("")
  const [searchResults, setSearchResults] = useState([])
  const [selectedUsers, setSelectedUsers] = useState([])
  const [loading, setLoading] = useState(false)
  const { createGroupChat } = useChat()

  const handleSearch = async (term) => {
    setSearchTerm(term)

    if (term.trim()) {
      try {
        const response = await userAPI.searchUsers(term)
        setSearchResults(response.data || [])
      } catch (error) {
        console.error("Search failed:", error)
        setSearchResults([])
      }
    } else {
      setSearchResults([])
    }
  }

  const handleUserSelect = (user) => {
    if (!selectedUsers.find((u) => u._id === user._id)) {
      setSelectedUsers([...selectedUsers, user])
    }
    setSearchTerm("")
    setSearchResults([])
  }

  const handleUserRemove = (userId) => {
    setSelectedUsers(selectedUsers.filter((u) => u._id !== userId))
  }

  const handleCreateGroup = async (e) => {
    e.preventDefault()

    if (!groupName.trim() || selectedUsers.length < 2) {
      alert("Please provide a group name and select at least 2 users")
      return
    }

    setLoading(true)
    try {
      const userIds = selectedUsers.map((u) => u._id)
      await createGroupChat(groupName, userIds)
      onClose()
    } catch (error) {
      console.error("Failed to create group:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal title="Create Group Chat" onClose={onClose}>
      <form onSubmit={handleCreateGroup} className="group-chat-modal">
        <div className="form-group">
          <label>Group Name</label>
          <input
            type="text"
            value={groupName}
            onChange={(e) => setGroupName(e.target.value)}
            placeholder="Enter group name..."
            required
          />
        </div>

        <div className="form-group">
          <label>Add Users</label>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="Search users to add..."
          />
        </div>

        {selectedUsers.length > 0 && (
          <div className="selected-users">
            <h4>Selected Users:</h4>
            <div className="selected-users-list">
              {selectedUsers.map((user) => (
                <div key={user._id} className="selected-user">
                  <span>{user.fullName}</span>
                  <button type="button" onClick={() => handleUserRemove(user._id)} className="remove-user-btn">
                    ×
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {searchResults.length > 0 && (
          <div className="search-results">
            {searchResults.map((user) => (
              <div key={user._id} className="user-result" onClick={() => handleUserSelect(user)}>
                <img
                  src={user.avatar || "/placeholder.svg?height=32&width=32"}
                  alt={user.fullName}
                  className="user-result-avatar"
                />
                <div className="user-result-info">
                  <h4>{user.fullName}</h4>
                  <p>{user.email}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="modal-actions">
          <button type="button" onClick={onClose} className="cancel-btn">
            Cancel
          </button>
          <button
            type="submit"
            className="create-btn"
            disabled={loading || !groupName.trim() || selectedUsers.length < 2}
          >
            {loading ? "Creating..." : "Create Group"}
          </button>
        </div>
      </form>
    </Modal>
  )
}

export default GroupChatModal
