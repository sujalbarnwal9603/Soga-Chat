"use client"

import { useState } from "react"
import { useAuth } from "../../contexts/AuthContext"
import { authAPI } from "../../services/api"
import Modal from "./Modal"
import toast from "react-hot-toast"
import "./ProfileModal.css"

const ProfileModal = ({ onClose }) => {
  const { user, updateProfile } = useAuth()
  const [activeTab, setActiveTab] = useState("profile")
  const [loading, setLoading] = useState(false)

  // Profile form state
  const [profileData, setProfileData] = useState({
    fullName: user?.fullName || "",
  })

  // Password form state
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  // Avatar state
  const [avatar, setAvatar] = useState(null)
  const [avatarPreview, setAvatarPreview] = useState(null)

  const handleProfileUpdate = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      await updateProfile(profileData)
    } catch (error) {
      console.error("Profile update failed:", error)
    } finally {
      setLoading(false)
    }
  }

  const handlePasswordChange = async (e) => {
    e.preventDefault()

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error("New passwords do not match")
      return
    }

    setLoading(true)
    try {
      await authAPI.changePassword({
        currentPassword: passwordData.currentPassword,
        newPassword: passwordData.newPassword,
      })

      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      })

      toast.success("Password changed successfully!")
    } catch (error) {
      toast.error(error.message)
    } finally {
      setLoading(false)
    }
  }

  const handleAvatarUpdate = async (e) => {
    e.preventDefault()
    if (!avatar) return

    setLoading(true)
    try {
      await authAPI.updateAvatar(avatar)
      setAvatar(null)
      setAvatarPreview(null)
      toast.success("Avatar updated successfully!")
    } catch (error) {
      toast.error(error.message)
    } finally {
      setLoading(false)
    }
  }

  const handleAvatarChange = (e) => {
    const file = e.target.files[0]
    setAvatar(file)

    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setAvatarPreview(reader.result)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <Modal title="Profile Settings" onClose={onClose}>
      <div className="profile-modal">
        <div className="profile-tabs">
          <button className={activeTab === "profile" ? "active" : ""} onClick={() => setActiveTab("profile")}>
            Profile
          </button>
          <button className={activeTab === "password" ? "active" : ""} onClick={() => setActiveTab("password")}>
            Password
          </button>
          <button className={activeTab === "avatar" ? "active" : ""} onClick={() => setActiveTab("avatar")}>
            Avatar
          </button>
        </div>

        <div className="tab-content">
          {activeTab === "profile" && (
            <form onSubmit={handleProfileUpdate}>
              <div className="form-group">
                <label>Full Name</label>
                <input
                  type="text"
                  value={profileData.fullName}
                  onChange={(e) =>
                    setProfileData({
                      ...profileData,
                      fullName: e.target.value,
                    })
                  }
                  required
                />
              </div>

              <div className="form-group">
                <label>Email</label>
                <input type="email" value={user?.email} disabled className="disabled-input" />
              </div>

              <button type="submit" disabled={loading}>
                {loading ? "Updating..." : "Update Profile"}
              </button>
            </form>
          )}

          {activeTab === "password" && (
            <form onSubmit={handlePasswordChange}>
              <div className="form-group">
                <label>Current Password</label>
                <input
                  type="password"
                  value={passwordData.currentPassword}
                  onChange={(e) =>
                    setPasswordData({
                      ...passwordData,
                      currentPassword: e.target.value,
                    })
                  }
                  required
                />
              </div>

              <div className="form-group">
                <label>New Password</label>
                <input
                  type="password"
                  value={passwordData.newPassword}
                  onChange={(e) =>
                    setPasswordData({
                      ...passwordData,
                      newPassword: e.target.value,
                    })
                  }
                  required
                />
              </div>

              <div className="form-group">
                <label>Confirm New Password</label>
                <input
                  type="password"
                  value={passwordData.confirmPassword}
                  onChange={(e) =>
                    setPasswordData({
                      ...passwordData,
                      confirmPassword: e.target.value,
                    })
                  }
                  required
                />
              </div>

              <button type="submit" disabled={loading}>
                {loading ? "Changing..." : "Change Password"}
              </button>
            </form>
          )}

          {activeTab === "avatar" && (
            <form onSubmit={handleAvatarUpdate}>
              <div className="current-avatar">
                <img
                  src={avatarPreview || user?.avatar || "/placeholder.svg?height=100&width=100"}
                  alt="Avatar"
                  className="avatar-preview-large"
                />
              </div>

              <div className="form-group">
                <label>New Avatar</label>
                <input type="file" accept="image/*" onChange={handleAvatarChange} />
              </div>

              <button type="submit" disabled={loading || !avatar}>
                {loading ? "Updating..." : "Update Avatar"}
              </button>
            </form>
          )}
        </div>
      </div>
    </Modal>
  )
}

export default ProfileModal
