"use client"

import { useState } from "react"
import { useAuth } from "../../contexts/AuthContext"
import { useNavigate } from "react-router-dom"

const RegisterForm = () => {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    avatar: null,
  })
  const [showPassword, setShowPassword] = useState(false)
  const [avatarPreview, setAvatarPreview] = useState(null)

  const { register, loading } = useAuth()
  const navigate = useNavigate()

  const handleChange = (e) => {
    if (e.target.name === "avatar") {
      const file = e.target.files[0]
      setFormData({
        ...formData,
        avatar: file,
      })

      if (file) {
        const reader = new FileReader()
        reader.onloadend = () => {
          setAvatarPreview(reader.result)
        }
        reader.readAsDataURL(file)
      }
    } else {
      setFormData({
        ...formData,
        [e.target.name]: e.target.value,
      })
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      await register(formData)
      navigate("/chat")
    } catch (error) {
      console.error("Registration failed:", error)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="auth-form-container">
      <div className="avatar-upload">
        <div className="avatar-preview">
          {avatarPreview ? (
            <img src={avatarPreview || "/placeholder.svg"} alt="Avatar preview" />
          ) : (
            <div className="avatar-placeholder">
              <span>📷</span>
            </div>
          )}
        </div>
        <label htmlFor="avatar" className="avatar-upload-btn">
          Choose Avatar
        </label>
        <input
          type="file"
          id="avatar"
          name="avatar"
          accept="image/*"
          onChange={handleChange}
          style={{ display: "none" }}
        />
      </div>

      <div className="form-group">
        <label htmlFor="fullName">Full Name</label>
        <input
          type="text"
          id="fullName"
          name="fullName"
          value={formData.fullName}
          onChange={handleChange}
          required
          placeholder="Enter your full name"
        />
      </div>

      <div className="form-group">
        <label htmlFor="email">Email</label>
        <input
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
          placeholder="Enter your email"
        />
      </div>

      <div className="form-group">
        <label htmlFor="password">Password</label>
        <div className="password-input">
          <input
            type={showPassword ? "text" : "password"}
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
            placeholder="Enter your password"
          />
          <button type="button" className="password-toggle" onClick={() => setShowPassword(!showPassword)}>
            {showPassword ? "👁️" : "👁️‍🗨️"}
          </button>
        </div>
      </div>

      <button type="submit" className="auth-button" disabled={loading}>
        {loading ? "Creating Account..." : "Register"}
      </button>
    </form>
  )
}

export default RegisterForm
