"use client"

import { useState } from "react"
import { Navigate } from "react-router-dom"
import { useAuth } from "../contexts/AuthContext"
import Sidebar from "../components/chat/Sidebar"
import ChatArea from "../components/chat/ChatArea"
import UserSearchModal from "../components/modals/UserSearchModal"
import GroupChatModal from "../components/modals/GroupChatModal"
import ProfileModal from "../components/modals/ProfileModal"
import "./ChatPage.css"

const ChatPage = () => {
  const { isAuthenticated, loading } = useAuth()
  const [showUserSearch, setShowUserSearch] = useState(false)
  const [showGroupModal, setShowGroupModal] = useState(false)
  const [showProfile, setShowProfile] = useState(false)

  if (loading) {
    return (
      <div className="chat-loading">
        <div className="spinner"></div>
        <p>Loading...</p>
      </div>
    )
  }

  if (!isAuthenticated) {
    return <Navigate to="/auth" replace />
  }

  return (
    <div className="chat-page">
      <Sidebar
        onShowUserSearch={() => setShowUserSearch(true)}
        onShowGroupModal={() => setShowGroupModal(true)}
        onShowProfile={() => setShowProfile(true)}
      />
      <ChatArea />

      {showUserSearch && <UserSearchModal onClose={() => setShowUserSearch(false)} />}

      {showGroupModal && <GroupChatModal onClose={() => setShowGroupModal(false)} />}

      {showProfile && <ProfileModal onClose={() => setShowProfile(false)} />}
    </div>
  )
}

export default ChatPage
