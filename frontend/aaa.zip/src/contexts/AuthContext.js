"use client"

import { createContext, useContext, useReducer, useEffect } from "react"
import { authAPI } from "../services/api"
import toast from "react-hot-toast"

const AuthContext = createContext()

const initialState = {
  user: null,
  isAuthenticated: false,
  loading: true,
  error: null,
}

const authReducer = (state, action) => {
  switch (action.type) {
    case "SET_LOADING":
      return { ...state, loading: action.payload }
    case "SET_USER":
      return {
        ...state,
        user: action.payload,
        isAuthenticated: true,
        loading: false,
        error: null,
      }
    case "SET_ERROR":
      return {
        ...state,
        error: action.payload,
        loading: false,
      }
    case "LOGOUT":
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        loading: false,
        error: null,
      }
    default:
      return state
  }
}

export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState)

  useEffect(() => {
    checkAuthStatus()
  }, [])

  const checkAuthStatus = async () => {
    try {
      const response = await authAPI.getCurrentUser()
      dispatch({ type: "SET_USER", payload: response.data })
    } catch (error) {
      dispatch({ type: "LOGOUT" })
    }
  }

  const login = async (credentials) => {
    try {
      dispatch({ type: "SET_LOADING", payload: true })
      const response = await authAPI.login(credentials)
      dispatch({ type: "SET_USER", payload: response.data.user })
      toast.success("Login successful!")
      return response
    } catch (error) {
      dispatch({ type: "SET_ERROR", payload: error.message })
      toast.error(error.message)
      throw error
    }
  }

  const register = async (userData) => {
    try {
      dispatch({ type: "SET_LOADING", payload: true })
      const response = await authAPI.register(userData)
      dispatch({ type: "SET_USER", payload: response.data })
      toast.success("Registration successful!")
      return response
    } catch (error) {
      dispatch({ type: "SET_ERROR", payload: error.message })
      toast.error(error.message)
      throw error
    }
  }

  const logout = async () => {
    try {
      await authAPI.logout()
      dispatch({ type: "LOGOUT" })
      toast.success("Logged out successfully!")
    } catch (error) {
      dispatch({ type: "LOGOUT" })
      toast.error("Logout failed")
    }
  }

  const updateProfile = async (profileData) => {
    try {
      const response = await authAPI.updateProfile(profileData)
      dispatch({ type: "SET_USER", payload: response.data })
      toast.success("Profile updated successfully!")
      return response
    } catch (error) {
      toast.error(error.message)
      throw error
    }
  }

  return (
    <AuthContext.Provider
      value={{
        ...state,
        login,
        register,
        logout,
        updateProfile,
        checkAuthStatus,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
