"use client"

import { createContext, useContext, useReducer, useEffect } from "react"
import { chatAPI, messageAPI } from "../services/api"
import { useSocket } from "./SocketContext"
import { useAuth } from "./AuthContext"
import toast from "react-hot-toast"

const ChatContext = createContext()

const initialState = {
  chats: [],
  selectedChat: null,
  messages: [],
  loading: false,
  typing: false,
  isTyping: false,
}

const chatReducer = (state, action) => {
  switch (action.type) {
    case "SET_LOADING":
      return { ...state, loading: action.payload }
    case "SET_CHATS":
      return { ...state, chats: action.payload }
    case "SET_SELECTED_CHAT":
      return { ...state, selectedChat: action.payload }
    case "SET_MESSAGES":
      return { ...state, messages: action.payload }
    case "ADD_MESSAGE":
      return { ...state, messages: [...state.messages, action.payload] }
    case "SET_TYPING":
      return { ...state, typing: action.payload }
    case "SET_IS_TYPING":
      return { ...state, isTyping: action.payload }
    case "UPDATE_CHAT":
      return {
        ...state,
        chats: state.chats.map((chat) => (chat._id === action.payload._id ? action.payload : chat)),
      }
    default:
      return state
  }
}

export const ChatProvider = ({ children }) => {
  const [state, dispatch] = useReducer(chatReducer, initialState)
  const { socket } = useSocket()
  const { user } = useAuth()

  useEffect(() => {
    fetchChats()
  }, [])

  useEffect(() => {
    if (socket) {
      socket.on("message received", (newMessage) => {
        if (!state.selectedChat || state.selectedChat._id !== newMessage.chat._id) {
          // Show notification for new message
          toast.success(`New message from ${newMessage.sender.fullName}`)
        } else {
          dispatch({ type: "ADD_MESSAGE", payload: newMessage })
        }
      })

      socket.on("typing", () => dispatch({ type: "SET_IS_TYPING", payload: true }))
      socket.on("stop typing", () => dispatch({ type: "SET_IS_TYPING", payload: false }))

      return () => {
        socket.off("message received")
        socket.off("typing")
        socket.off("stop typing")
      }
    }
  }, [socket, state.selectedChat])

  const fetchChats = async () => {
    try {
      dispatch({ type: "SET_LOADING", payload: true })
      const response = await chatAPI.fetchChats()
      dispatch({ type: "SET_CHATS", payload: response.data })
    } catch (error) {
      toast.error("Failed to fetch chats")
    } finally {
      dispatch({ type: "SET_LOADING", payload: false })
    }
  }

  const selectChat = async (chat) => {
    dispatch({ type: "SET_SELECTED_CHAT", payload: chat })

    if (socket) {
      socket.emit("join chat", chat._id)
    }

    try {
      const response = await messageAPI.getAllMessages(chat._id)
      dispatch({ type: "SET_MESSAGES", payload: response.data })
    } catch (error) {
      toast.error("Failed to fetch messages")
    }
  }

  const sendMessage = async (content) => {
    if (!state.selectedChat) return

    try {
      const response = await messageAPI.sendMessage({
        content,
        chatId: state.selectedChat._id,
      })

      if (socket) {
        socket.emit("new message", response.data)
      }

      dispatch({ type: "ADD_MESSAGE", payload: response.data })
      fetchChats() // Refresh chats to update latest message
    } catch (error) {
      toast.error("Failed to send message")
    }
  }

  const createChat = async (userId) => {
    try {
      const response = await chatAPI.accessChat({ userId })
      await fetchChats()
      return response.data
    } catch (error) {
      toast.error("Failed to create chat")
      throw error
    }
  }

  const createGroupChat = async (name, users) => {
    try {
      const response = await chatAPI.createGroupChat({ name, users })
      await fetchChats()
      toast.success("Group chat created successfully!")
      return response.data
    } catch (error) {
      toast.error("Failed to create group chat")
      throw error
    }
  }

  return (
    <ChatContext.Provider
      value={{
        ...state,
        fetchChats,
        selectChat,
        sendMessage,
        createChat,
        createGroupChat,
        dispatch,
      }}
    >
      {children}
    </ChatContext.Provider>
  )
}

export const useChat = () => {
  const context = useContext(ChatContext)
  if (!context) {
    throw new Error("useChat must be used within a ChatProvider")
  }
  return context
}
