const API_BASE_URL = process.env.REACT_APP_API_URL || "http://localhost:8000/api/v1"

class ApiService {
  async request(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`
    const config = {
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
      ...options,
    }

    if (config.body && typeof config.body === "object" && !(config.body instanceof FormData)) {
      config.body = JSON.stringify(config.body)
    }

    try {
      const response = await fetch(url, config)
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Something went wrong")
      }

      return data
    } catch (error) {
      throw error
    }
  }
}

const apiService = new ApiService()

// Auth API
export const authAPI = {
  register: (userData) => {
    const formData = new FormData()
    Object.keys(userData).forEach((key) => {
      if (key === "avatar" && userData[key]) {
        formData.append("avatar", userData[key])
      } else {
        formData.append(key, userData[key])
      }
    })

    return apiService.request("/auth/register", {
      method: "POST",
      body: formData,
      headers: {}, // Remove Content-Type for FormData
    })
  },

  login: (credentials) =>
    apiService.request("/auth/login", {
      method: "POST",
      body: credentials,
    }),

  logout: () =>
    apiService.request("/auth/logout", {
      method: "POST",
    }),

  getCurrentUser: () => apiService.request("/auth/me"),

  changePassword: (passwordData) =>
    apiService.request("/auth/change-password", {
      method: "POST",
      body: passwordData,
    }),

  updateProfile: (profileData) =>
    apiService.request("/auth/change-name", {
      method: "PUT",
      body: profileData,
    }),

  updateAvatar: (avatar) => {
    const formData = new FormData()
    formData.append("avatar", avatar)

    return apiService.request("/auth/update-avatar", {
      method: "PUT",
      body: formData,
      headers: {},
    })
  },
}

// Chat API
export const chatAPI = {
  fetchChats: () => apiService.request("/chat"),

  accessChat: (data) =>
    apiService.request("/chat", {
      method: "POST",
      body: data,
    }),

  createGroupChat: (data) =>
    apiService.request("/chat/group", {
      method: "POST",
      body: data,
    }),

  renameGroup: (data) =>
    apiService.request("/chat/rename", {
      method: "PUT",
      body: data,
    }),

  addToGroup: (data) =>
    apiService.request("/chat/group-add", {
      method: "PUT",
      body: data,
    }),

  removeFromGroup: (data) =>
    apiService.request("/chat/group-remove", {
      method: "PUT",
      body: data,
    }),
}

// Message API
export const messageAPI = {
  sendMessage: (data) =>
    apiService.request("/message", {
      method: "POST",
      body: data,
    }),

  getAllMessages: (chatId) => apiService.request(`/message/${chatId}`),
}

// User search (you'll need to add this endpoint to your backend)
export const userAPI = {
  searchUsers: (search) => apiService.request(`/auth/search?search=${search}`),
}
