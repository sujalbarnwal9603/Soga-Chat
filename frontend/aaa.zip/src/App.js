import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import { AuthProvider } from "./contexts/AuthContext"
import { ChatProvider } from "./contexts/ChatContext"
import { SocketProvider } from "./contexts/SocketContext"
import AuthPage from "./pages/AuthPage"
import ChatPage from "./pages/ChatPage"
import ProtectedRoute from "./components/ProtectedRoute"
import { Toaster } from "react-hot-toast"
import "./App.css"

function App() {
  return (
    <div className="App">
      <AuthProvider>
        <Router>
          <Routes>
            <Route path="/auth" element={<AuthPage />} />
            <Route
              path="/chat"
              element={
                <ProtectedRoute>
                  <SocketProvider>
                    <ChatProvider>
                      <ChatPage />
                    </ChatProvider>
                  </SocketProvider>
                </ProtectedRoute>
              }
            />
            <Route path="/" element={<Navigate to="/chat" replace />} />
          </Routes>
        </Router>
      </AuthProvider>
      <Toaster position="top-right" />
    </div>
  )
}

export default App
