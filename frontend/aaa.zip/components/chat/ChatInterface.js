"use client"

import { useState } from "react"
import { useAuth } from "../../context/AuthContext"
import { useChat } from "../../context/ChatContext"
import ChatList from "./ChatList"
import MessageArea from "./MessageArea"
import UserSearch from "./UserSearch"
import GroupChatModal from "./GroupChatModal"

const ChatInterface = () => {
  const { user, logout } = useAuth()
  const { selectedChat } = useChat()
  const [showUserSearch, setShowUserSearch] = useState(false)
  const [showGroupModal, setShowGroupModal] = useState(false)

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-1/3 bg-white border-r border-gray-300 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-300 bg-gray-50">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img
                src={user?.avatar || "/placeholder.svg?height=40&width=40"}
                alt={user?.fullName}
                className="w-10 h-10 rounded-full object-cover"
              />
              <div>
                <h3 className="font-semibold text-gray-900">{user?.fullName}</h3>
                <p className="text-sm text-gray-500">Online</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={() => setShowUserSearch(true)}
                className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-200 rounded-full"
                title="New Chat"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
              </button>
              <button
                onClick={() => setShowGroupModal(true)}
                className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-200 rounded-full"
                title="New Group"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                  />
                </svg>
              </button>
              <button
                onClick={logout}
                className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-200 rounded-full"
                title="Logout"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                  />
                </svg>
              </button>
            </div>
          </div>
        </div>

        {/* Chat List */}
        <ChatList />
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {selectedChat ? (
          <MessageArea />
        ) : (
          <div className="flex-1 flex items-center justify-center bg-gray-50">
            <div className="text-center">
              <div className="text-6xl mb-4">💬</div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">Welcome to Chat App</h3>
              <p className="text-gray-500">Select a chat to start messaging</p>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      {showUserSearch && <UserSearch onClose={() => setShowUserSearch(false)} />}

      {showGroupModal && <GroupChatModal onClose={() => setShowGroupModal(false)} />}
    </div>
  )
}

export default ChatInterface
