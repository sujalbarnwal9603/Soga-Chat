"use client"

import { useState } from "react"
import { useChat } from "../../context/ChatContext"
import apiService from "../../services/api"

const GroupChatModal = ({ onClose }) => {
  const [groupName, setGroupName] = useState("")
  const [searchTerm, setSearchTerm] = useState("")
  const [searchResults, setSearchResults] = useState([])
  const [selectedUsers, setSelectedUsers] = useState([])
  const [loading, setLoading] = useState(false)
  const { createGroupChat } = useChat()

  const handleSearch = async (e) => {
    const term = e.target.value
    setSearchTerm(term)

    if (term.trim()) {
      try {
        const response = await apiService.searchUsers(term)
        setSearchResults(response.data || [])
      } catch (error) {
        console.error("Search failed:", error)
        setSearchResults([])
      }
    } else {
      setSearchResults([])
    }
  }

  const handleUserSelect = (user) => {
    if (!selectedUsers.find((u) => u._id === user._id)) {
      setSelectedUsers([...selectedUsers, user])
    }
    setSearchTerm("")
    setSearchResults([])
  }

  const handleUserRemove = (userId) => {
    setSelectedUsers(selectedUsers.filter((u) => u._id !== userId))
  }

  const handleCreateGroup = async (e) => {
    e.preventDefault()
    if (!groupName.trim() || selectedUsers.length < 2) {
      alert("Please provide a group name and select at least 2 users")
      return
    }

    setLoading(true)
    try {
      const userIds = selectedUsers.map((u) => u._id)
      await createGroupChat(groupName, userIds)
      onClose()
    } catch (error) {
      console.error("Failed to create group:", error)
      alert("Failed to create group chat")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Create Group Chat</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <form onSubmit={handleCreateGroup} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Group Name</label>
            <input
              type="text"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="Enter group name..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Add Users</label>
            <input
              type="text"
              value={searchTerm}
              onChange={handleSearch}
              placeholder="Search users to add..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Selected Users */}
          {selectedUsers.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {selectedUsers.map((user) => (
                <div
                  key={user._id}
                  className="flex items-center space-x-2 bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm"
                >
                  <span>{user.fullName}</span>
                  <button
                    type="button"
                    onClick={() => handleUserRemove(user._id)}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Search Results */}
          {searchResults.length > 0 && (
            <div className="max-h-40 overflow-y-auto border border-gray-200 rounded-lg">
              {searchResults.map((user) => (
                <div
                  key={user._id}
                  onClick={() => handleUserSelect(user)}
                  className="flex items-center space-x-3 p-3 hover:bg-gray-100 cursor-pointer"
                >
                  <img
                    src={user.avatar || "/placeholder.svg?height=32&width=32"}
                    alt={user.fullName}
                    className="w-8 h-8 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="font-medium text-gray-900">{user.fullName}</h4>
                    <p className="text-sm text-gray-500">{user.email}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || !groupName.trim() || selectedUsers.length < 2}
              className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? "Creating..." : "Create Group"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default GroupChatModal
