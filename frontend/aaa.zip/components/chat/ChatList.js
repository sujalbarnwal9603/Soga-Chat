"use client"
import { useChat } from "../../context/ChatContext"
import { useAuth } from "../../context/AuthContext"

const ChatList = () => {
  const { chats, selectedChat, selectChat, loading } = useChat()
  const { user } = useAuth()

  const getSender = (chat) => {
    if (chat.isGroupChat) {
      return chat.chatName
    }
    return chat.users.find((u) => u._id !== user._id)?.fullName || "Unknown User"
  }

  const getSenderAvatar = (chat) => {
    if (chat.isGroupChat) {
      return "/placeholder.svg?height=40&width=40"
    }
    const sender = chat.users.find((u) => u._id !== user._id)
    return sender?.avatar || "/placeholder.svg?height=40&width=40"
  }

  const formatTime = (timestamp) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffInHours = (now - date) / (1000 * 60 * 60)

    if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } else {
      return date.toLocaleDateString()
    }
  }

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-gray-500">Loading chats...</div>
      </div>
    )
  }

  return (
    <div className="flex-1 overflow-y-auto">
      {chats.length === 0 ? (
        <div className="p-4 text-center text-gray-500">No chats yet. Start a new conversation!</div>
      ) : (
        chats.map((chat) => (
          <div
            key={chat._id}
            onClick={() => selectChat(chat)}
            className={`p-4 border-b border-gray-200 cursor-pointer hover:bg-gray-50 ${
              selectedChat?._id === chat._id ? "bg-blue-50 border-blue-200" : ""
            }`}
          >
            <div className="flex items-center space-x-3">
              <div className="relative">
                <img
                  src={getSenderAvatar(chat) || "/placeholder.svg"}
                  alt={getSender(chat)}
                  className="w-12 h-12 rounded-full object-cover"
                />
                {chat.isGroupChat && (
                  <div className="absolute -bottom-1 -right-1 bg-green-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                    {chat.users.length}
                  </div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-gray-900 truncate">{getSender(chat)}</h4>
                  {chat.latestMessage && (
                    <span className="text-xs text-gray-500">{formatTime(chat.latestMessage.createdAt)}</span>
                  )}
                </div>

                {chat.latestMessage && (
                  <p className="text-sm text-gray-600 truncate">
                    {chat.latestMessage.sender._id === user._id ? "You: " : ""}
                    {chat.latestMessage.content}
                  </p>
                )}

                {chat.isGroupChat && <p className="text-xs text-gray-500">{chat.users.length} members</p>}
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  )
}

export default ChatList
