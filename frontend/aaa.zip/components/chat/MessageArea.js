"use client"

import { useState, useRef, useEffect } from "react"
import { useChat } from "../../context/ChatContext"
import { useAuth } from "../../context/AuthContext"

const MessageArea = () => {
  const { selectedChat, messages, sendMessage } = useChat()
  const { user } = useAuth()
  const [newMessage, setNewMessage] = useState("")
  const messagesEndRef = useRef(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async (e) => {
    e.preventDefault()
    if (newMessage.trim()) {
      await sendMessage(newMessage)
      setNewMessage("")
    }
  }

  const getSender = () => {
    if (selectedChat.isGroupChat) {
      return selectedChat.chatName
    }
    return selectedChat.users.find((u) => u._id !== user._id)?.fullName || "Unknown User"
  }

  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const isSameUser = (messages, m, i) => {
    return i > 0 && messages[i - 1].sender._id === m.sender._id
  }

  const isLastMessage = (messages, i, userId) => {
    return (
      i === messages.length - 1 ||
      (messages[i + 1].sender._id !== messages[i].sender._id && messages[i].sender._id !== userId)
    )
  }

  return (
    <div className="flex flex-col h-full">
      {/* Chat Header */}
      <div className="p-4 border-b border-gray-300 bg-white">
        <div className="flex items-center space-x-3">
          <img
            src={
              selectedChat.isGroupChat
                ? "/placeholder.svg?height=40&width=40"
                : selectedChat.users.find((u) => u._id !== user._id)?.avatar || "/placeholder.svg?height=40&width=40"
            }
            alt={getSender()}
            className="w-10 h-10 rounded-full object-cover"
          />
          <div>
            <h3 className="font-semibold text-gray-900">{getSender()}</h3>
            {selectedChat.isGroupChat ? (
              <p className="text-sm text-gray-500">{selectedChat.users.length} members</p>
            ) : (
              <p className="text-sm text-gray-500">Online</p>
            )}
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
        {messages.map((message, index) => (
          <div
            key={message._id}
            className={`flex ${message.sender._id === user._id ? "justify-end" : "justify-start"}`}
          >
            <div
              className={`flex items-end space-x-2 max-w-xs lg:max-w-md ${
                message.sender._id === user._id ? "flex-row-reverse space-x-reverse" : ""
              }`}
            >
              {/* Avatar */}
              {(!isSameUser(messages, message, index) || isLastMessage(messages, index, user._id)) && (
                <img
                  src={message.sender.avatar || "/placeholder.svg?height=32&width=32"}
                  alt={message.sender.fullName}
                  className="w-8 h-8 rounded-full object-cover"
                />
              )}

              {/* Message Bubble */}
              <div
                className={`px-4 py-2 rounded-lg ${
                  message.sender._id === user._id
                    ? "bg-blue-500 text-white"
                    : "bg-white text-gray-900 border border-gray-200"
                }`}
              >
                {selectedChat.isGroupChat && message.sender._id !== user._id && (
                  <p className="text-xs font-semibold mb-1 text-blue-600">{message.sender.fullName}</p>
                )}
                <p className="text-sm">{message.content}</p>
                <p className={`text-xs mt-1 ${message.sender._id === user._id ? "text-blue-100" : "text-gray-500"}`}>
                  {formatTime(message.createdAt)}
                </p>
              </div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="p-4 border-t border-gray-300 bg-white">
        <form onSubmit={handleSendMessage} className="flex space-x-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            type="submit"
            disabled={!newMessage.trim()}
            className="px-6 py-2 bg-blue-500 text-white rounded-full hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  )
}

export default MessageArea
