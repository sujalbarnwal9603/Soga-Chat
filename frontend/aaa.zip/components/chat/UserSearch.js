"use client"

import { useState } from "react"
import { useChat } from "../../context/ChatContext"
import apiService from "../../services/api"

const UserSearch = ({ onClose }) => {
  const [searchTerm, setSearchTerm] = useState("")
  const [searchResults, setSearchResults] = useState([])
  const [loading, setLoading] = useState(false)
  const { fetchChats } = useChat()

  const handleSearch = async (e) => {
    const term = e.target.value
    setSearchTerm(term)

    if (term.trim()) {
      setLoading(true)
      try {
        const response = await apiService.searchUsers(term)
        setSearchResults(response.data || [])
      } catch (error) {
        console.error("Search failed:", error)
        setSearchResults([])
      } finally {
        setLoading(false)
      }
    } else {
      setSearchResults([])
    }
  }

  const handleUserSelect = async (userId) => {
    try {
      await apiService.accessChat(userId)
      await fetchChats()
      onClose()
    } catch (error) {
      console.error("Failed to create chat:", error)
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Search Users</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="mb-4">
          <input
            type="text"
            placeholder="Search by name or email..."
            value={searchTerm}
            onChange={handleSearch}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            autoFocus
          />
        </div>

        <div className="max-h-60 overflow-y-auto">
          {loading ? (
            <div className="text-center py-4 text-gray-500">Searching...</div>
          ) : searchResults.length > 0 ? (
            <div className="space-y-2">
              {searchResults.map((user) => (
                <div
                  key={user._id}
                  onClick={() => handleUserSelect(user._id)}
                  className="flex items-center space-x-3 p-3 hover:bg-gray-100 rounded-lg cursor-pointer"
                >
                  <img
                    src={user.avatar || "/placeholder.svg?height=40&width=40"}
                    alt={user.fullName}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="font-medium text-gray-900">{user.fullName}</h4>
                    <p className="text-sm text-gray-500">{user.email}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : searchTerm && !loading ? (
            <div className="text-center py-4 text-gray-500">No users found</div>
          ) : (
            <div className="text-center py-4 text-gray-500">Start typing to search for users</div>
          )}
        </div>
      </div>
    </div>
  )
}

export default UserSearch
