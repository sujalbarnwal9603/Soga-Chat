const API_BASE_URL = process.env.REACT_APP_API_URL || "http://localhost:8000/api/v1"

class ApiService {
  constructor() {
    this.baseURL = API_BASE_URL
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`
    const config = {
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
      credentials: "include",
      ...options,
    }

    if (config.body && typeof config.body === "object" && !(config.body instanceof FormData)) {
      config.body = JSON.stringify(config.body)
    }

    try {
      const response = await fetch(url, config)
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Something went wrong")
      }

      return data
    } catch (error) {
      throw error
    }
  }

  // Auth endpoints
  async register(userData) {
    const formData = new FormData()
    Object.keys(userData).forEach((key) => {
      if (key === "avatar" && userData[key]) {
        formData.append("avatar", userData[key])
      } else {
        formData.append(key, userData[key])
      }
    })

    return this.request("/users/register", {
      method: "POST",
      body: formData,
      headers: {}, // Remove Content-Type to let browser set it for FormData
    })
  }

  async login(credentials) {
    return this.request("/users/login", {
      method: "POST",
      body: credentials,
    })
  }

  async logout() {
    return this.request("/users/logout", {
      method: "POST",
    })
  }

  async getCurrentUser() {
    return this.request("/users/current-user")
  }

  async refreshToken() {
    return this.request("/users/refresh-token", {
      method: "POST",
    })
  }

  // Chat endpoints
  async accessChat(userId) {
    return this.request("/chats", {
      method: "POST",
      body: { userId },
    })
  }

  async fetchChats() {
    return this.request("/chats")
  }

  async createGroupChat(name, users) {
    return this.request("/chats/group", {
      method: "POST",
      body: { name, users },
    })
  }

  async renameGroup(chatId, chatName) {
    return this.request("/chats/rename", {
      method: "PUT",
      body: { chatId, chatName },
    })
  }

  async addToGroup(chatId, userId) {
    return this.request("/chats/groupadd", {
      method: "PUT",
      body: { chatId, userId },
    })
  }

  async removeFromGroup(chatId, userId) {
    return this.request("/chats/groupremove", {
      method: "PUT",
      body: { chatId, userId },
    })
  }

  // Message endpoints
  async sendMessage(content, chatId) {
    return this.request("/messages", {
      method: "POST",
      body: { content, chatId },
    })
  }

  async getAllMessages(chatId) {
    return this.request(`/messages/${chatId}`)
  }

  // User search
  async searchUsers(search) {
    return this.request(`/users?search=${search}`)
  }
}

export default new ApiService()
