"use client"

import { useState } from "react"
import { AuthProvider, useAuth } from "./context/AuthContext"
import { ChatProvider } from "./context/ChatContext"
import Login from "./components/auth/Login"
import Register from "./components/auth/Register"
import ChatInterface from "./components/chat/ChatInterface"

const AuthWrapper = () => {
  const { isAuthenticated, loading } = useAuth()
  const [isLoginMode, setIsLoginMode] = useState(true)

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return isLoginMode ? (
      <Login onToggleMode={() => setIsLoginMode(false)} />
    ) : (
      <Register onToggleMode={() => setIsLoginMode(true)} />
    )
  }

  return (
    <ChatProvider>
      <ChatInterface />
    </ChatProvider>
  )
}

function App() {
  return (
    <AuthProvider>
      <AuthWrapper />
    </AuthProvider>
  )
}

export default App
