"use client"

import { createContext, useContext, useReducer, useEffect } from "react"
import { useAuth } from "./AuthContext"
import apiService from "../services/api"
import io from "socket.io-client"

const ChatContext = createContext()

const chatReducer = (state, action) => {
  switch (action.type) {
    case "SET_CHATS":
      return { ...state, chats: action.payload }
    case "SET_SELECTED_CHAT":
      return { ...state, selectedChat: action.payload }
    case "SET_MESSAGES":
      return { ...state, messages: action.payload }
    case "ADD_MESSAGE":
      return { ...state, messages: [...state.messages, action.payload] }
    case "SET_LOADING":
      return { ...state, loading: action.payload }
    case "SET_SOCKET":
      return { ...state, socket: action.payload }
    case "SET_ONLINE_USERS":
      return { ...state, onlineUsers: action.payload }
    default:
      return state
  }
}

export const ChatProvider = ({ children }) => {
  const { user, isAuthenticated } = useAuth()
  const [state, dispatch] = useReducer(chatReducer, {
    chats: [],
    selectedChat: null,
    messages: [],
    loading: false,
    socket: null,
    onlineUsers: [],
  })

  useEffect(() => {
    if (isAuthenticated && user) {
      initializeSocket()
      fetchChats()
    }
    return () => {
      if (state.socket) {
        state.socket.disconnect()
      }
    }
  }, [isAuthenticated, user])

  const initializeSocket = () => {
    const socket = io(process.env.REACT_APP_SOCKET_URL || "http://localhost:8000")

    socket.emit("setup", user)

    socket.on("connected", () => {
      console.log("Connected to socket")
    })

    socket.on("message received", (newMessage) => {
      dispatch({ type: "ADD_MESSAGE", payload: newMessage })
    })

    socket.on("online users", (users) => {
      dispatch({ type: "SET_ONLINE_USERS", payload: users })
    })

    dispatch({ type: "SET_SOCKET", payload: socket })
  }

  const fetchChats = async () => {
    try {
      dispatch({ type: "SET_LOADING", payload: true })
      const response = await apiService.fetchChats()
      dispatch({ type: "SET_CHATS", payload: response.data })
    } catch (error) {
      console.error("Error fetching chats:", error)
    } finally {
      dispatch({ type: "SET_LOADING", payload: false })
    }
  }

  const selectChat = async (chat) => {
    dispatch({ type: "SET_SELECTED_CHAT", payload: chat })

    if (state.socket) {
      state.socket.emit("join chat", chat._id)
    }

    try {
      const response = await apiService.getAllMessages(chat._id)
      dispatch({ type: "SET_MESSAGES", payload: response.data })
    } catch (error) {
      console.error("Error fetching messages:", error)
    }
  }

  const sendMessage = async (content) => {
    if (!state.selectedChat) return

    try {
      const response = await apiService.sendMessage(content, state.selectedChat._id)

      if (state.socket) {
        state.socket.emit("new message", response.data)
      }

      dispatch({ type: "ADD_MESSAGE", payload: response.data })
      await fetchChats() // Refresh chats to update latest message
    } catch (error) {
      console.error("Error sending message:", error)
    }
  }

  const createGroupChat = async (name, users) => {
    try {
      const response = await apiService.createGroupChat(name, users)
      await fetchChats()
      return response.data
    } catch (error) {
      console.error("Error creating group chat:", error)
      throw error
    }
  }

  return (
    <ChatContext.Provider
      value={{
        ...state,
        fetchChats,
        selectChat,
        sendMessage,
        createGroupChat,
      }}
    >
      {children}
    </ChatContext.Provider>
  )
}

export const useChat = () => {
  const context = useContext(ChatContext)
  if (!context) {
    throw new Error("useChat must be used within a ChatProvider")
  }
  return context
}
