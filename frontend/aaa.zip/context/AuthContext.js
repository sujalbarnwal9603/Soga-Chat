"use client"

import { createContext, useContext, useReducer, useEffect } from "react"
import apiService from "../services/api"

const AuthContext = createContext()

const authReducer = (state, action) => {
  switch (action.type) {
    case "LOGIN_START":
      return { ...state, loading: true, error: null }
    case "LOGIN_SUCCESS":
      return { ...state, loading: false, user: action.payload, isAuthenticated: true }
    case "LOGIN_FAILURE":
      return { ...state, loading: false, error: action.payload, isAuthenticated: false }
    case "LOGOUT":
      return { ...state, user: null, isAuthenticated: false, loading: false }
    case "SET_USER":
      return { ...state, user: action.payload, isAuthenticated: true, loading: false }
    case "SET_LOADING":
      return { ...state, loading: action.payload }
    default:
      return state
  }
}

export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, {
    user: null,
    isAuthenticated: false,
    loading: true,
    error: null,
  })

  useEffect(() => {
    checkAuthStatus()
  }, [])

  const checkAuthStatus = async () => {
    try {
      const response = await apiService.getCurrentUser()
      dispatch({ type: "SET_USER", payload: response.data })
    } catch (error) {
      dispatch({ type: "LOGOUT" })
    } finally {
      dispatch({ type: "SET_LOADING", payload: false })
    }
  }

  const login = async (credentials) => {
    dispatch({ type: "LOGIN_START" })
    try {
      const response = await apiService.login(credentials)
      dispatch({ type: "LOGIN_SUCCESS", payload: response.data.user })
      return response
    } catch (error) {
      dispatch({ type: "LOGIN_FAILURE", payload: error.message })
      throw error
    }
  }

  const register = async (userData) => {
    dispatch({ type: "LOGIN_START" })
    try {
      const response = await apiService.register(userData)
      dispatch({ type: "LOGIN_SUCCESS", payload: response.data })
      return response
    } catch (error) {
      dispatch({ type: "LOGIN_FAILURE", payload: error.message })
      throw error
    }
  }

  const logout = async () => {
    try {
      await apiService.logout()
      dispatch({ type: "LOGOUT" })
    } catch (error) {
      dispatch({ type: "LOGOUT" })
    }
  }

  return <AuthContext.Provider value={{ ...state, login, register, logout }}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
